var data = {
    temp:10,
    temp:50,
    temp:80,
    temp:90
    }
console.log(data.temp)
