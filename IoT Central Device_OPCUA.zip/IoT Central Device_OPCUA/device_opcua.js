"use strict";

// Use the Azure IoT device SDK for devices that connect to Azure IoT Central.
var iotHubTransport = require('azure-iot-device-mqtt').Mqtt;
var Client = require('azure-iot-device').Client;
var Message = require('azure-iot-device').Message;
var ProvisioningTransport = require('azure-iot-provisioning-device-mqtt').Mqtt;
var SymmetricKeySecurityClient = require('azure-iot-security-symmetric-key').SymmetricKeySecurityClient;
var ProvisioningDeviceClient = require('azure-iot-provisioning-device').ProvisioningDeviceClient;

var provisioningHost = 'global.azure-devices-provisioning.net';
var idScope = 'idscope';
var registrationId = 'device id';
var symmetricKey = 'primary sas key';
//var idScope = '0ne00088FDE';
//var registrationId = '1vsjxfhhk2k';
//var symmetricKey = 'v3pXHWQVdk+CwmyibAbz2VszrmxyJya6PB5TC5Fnjc8=';
var provisioningSecurityClient = new SymmetricKeySecurityClient(registrationId, symmetricKey);
var provisioningClient = ProvisioningDeviceClient.create(provisioningHost, idScope, new ProvisioningTransport(), provisioningSecurityClient);
var hubClient;
var targetValue = 0;
var location = 0;

// Send device measurements.
function sendTelemetry() {
  var doubleValue = targetValue+ + (Math.random() * 15);
  var eventValue = 15;
  var locationLong=  -122.128519 - location;
  var locationLat = 47.643619 - location;
  location = location + .01;
  //eventInformation: eventValue,
  var data = JSON.stringify({
    MessageType: 'ua-data',
    Messages: [{
        DataSetWriterId: 'data-transform-1_10000_dd587900-9159-4d20-b93e-ed601b70a7b6',
        MetaDataVersion: {
            MajorVersion: 1,
            MinorVersion: 0
        },
        Payload: {
            'nsu=http://microsoft.com/Opc/OpcPlc/;s=FastUInt1': {
                ServerTimestamp: '2020-12-04T00:08:04.1004748Z',
                SourceTimestamp: '2020-12-04T00:08:04.1004691Z',
                Value: 869567
            },
            'nsu=http://microsoft.com/Opc/OpcPlc/;s=FastUInt2': {
                ServerTimestamp: '2020-12-04T00:08:04.1004748Z',
                SourceTimestamp: '2020-12-04T00:08:04.1004691Z',
                Value: 869568
            },
            'nsu=http://microsoft.com/Opc/OpcPlc/;s=FastUInt3': {
                ServerTimestamp: '2020-12-04T00:08:04.1004748Z',
                SourceTimestamp: '2020-12-04T00:08:04.1004691Z',
                Value: 869511
            },
            'nsu=http://microsoft.com/Opc/OpcPlc/;s=FastUInt4': {
                ServerTimestamp: '2020-12-04T00:08:04.1004748Z',
                SourceTimestamp: '2020-12-04T00:08:04.1004691Z',
                Value: 869500
            },
            'nsu=http://microsoft.com/Opc/OpcPlc/;s=FastUInt5': {
                ServerTimestamp: '2020-12-04T00:08:04.1004748Z',
                SourceTimestamp: '2020-12-04T00:08:04.1004691Z',
                Value: 869556
            },
            'nsu=http://microsoft.com/Opc/OpcPlc/;s=FastUInt6': {
                ServerTimestamp: '2020-12-04T00:08:04.1004748Z',
                SourceTimestamp: '2020-12-04T00:08:04.1004691Z',
                Value: 869578
            },
            'nsu=http://microsoft.com/Opc/OpcPlc/;s=FastUInt7': {
                ServerTimestamp: '2020-12-04T00:08:04.1004748Z',
                SourceTimestamp: '2020-12-04T00:08:04.1004691Z',
                Value: 869556
            }
        }
    }]
});
  var message = new Message(data);

  hubClient.sendEvent(message, (err, res) => console.log(`Sent message: ${message.getData()}` +
    (err ? `; error: ${err.toString()}` : '') +
    (res ? `; status: ${res.constructor.name}` : '')));
}

// Send device twin reported properties.
function sendDeviceProperties(twin, properties) {
  twin.properties.reported.update(properties, (err) => console.log(`Sent device properties: ${JSON.stringify(properties)}; ` +
    (err ? `error: ${err.toString()}` : `status: success`)));
}

// Handle sensor diagnostics command
function diagnostics(request, response) {
  console.log('Received asynchronous call to run diagnostics');
  response.send(200, (err) => {
    if (err) {
      console.error('Unable to send method response: ' + err.toString());
    } else {
      console.log('Running diagnostics...');
    }
  });
}

// Handle device connection to Azure IoT Central.
var connectCallback = (err) => {
  if (err) {
    console.log(`Device could not connect to Azure IoT Central: ${err.toString()}`);
  } else {
    console.log('Device successfully connected to Azure IoT Central');
    // Create handlers for commands
    
    hubClient.onDeviceMethod('rundiagnostics', diagnostics);
    // Send telemetry measurements to Azure IoT Central every 1 second.
    setInterval(sendTelemetry, 10000);

    hubClient.getTwin((err, twin) => {
      if (err) {
        console.log(`Error getting device twin: ${err.toString()}`);
      } else {
        // Send device properties once on device start up.
        var locationLong=  -122.128519;
        var locationLat = 47.643619;

        var properties = {
          Location: {
            lon: locationLat,
            lat: locationLong
            }
          }
        sendDeviceProperties(twin, properties);
      }
    });
  }
};

// Start the device (register and connect to Azure IoT Central).
provisioningClient.register((err, result) => {
  if (err) {
    console.log('Error registering device: ' + err);
  } else {
    console.log('Registration succeeded');
    console.log('Assigned hub=' + result.assignedHub);
    console.log('DeviceId=' + result.deviceId);
    var connectionString = 'HostName=' + result.assignedHub + ';DeviceId=' + result.deviceId + ';SharedAccessKey=' + symmetricKey;
    hubClient = Client.fromConnectionString(connectionString, iotHubTransport);
    hubClient.open(connectCallback);
  }
});



//{"battery":29.68342159859524,"location":{"lon":-88.8033,"lat":34.3301,"alt":8.5973}}